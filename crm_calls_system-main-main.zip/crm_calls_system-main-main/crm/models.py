from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    """Extends the default Django User with a CRM role."""

    ROLE_CHOICES = [
        ('sales', 'Sales'),
        ('sales_leader', 'Sales Leader'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='sales')

    class Meta:
        db_table = 'crm_user_profile'

    def __str__(self):
        return f"{self.user.username} — {self.get_role_display()}"

    @property
    def is_sales_leader(self):
        return self.role == 'sales_leader'

    @property
    def is_sales(self):
        return self.role == 'sales'


class CallsResponse(models.Model):
    """Maps to calls_response table in sheets_calls DB"""
    lead_owner = models.TextField(blank=True, null=True)
    phone_number = models.TextField(blank=True, null=True)
    client_code = models.TextField(blank=True, null=True)
    client_name = models.TextField(blank=True, null=True)
    project_name = models.TextField(blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=100, blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    email_address = models.EmailField(blank=True, null=True)
    location = models.TextField(blank=True, null=True)
    manager_comments = models.TextField(blank=True, null=True)
    standard_lead_owner = models.TextField(blank=True, null=True)
    broker_name = models.TextField(blank=True, null=True)
    id = models.IntegerField(primary_key=True)

    class Meta:
        db_table = 'calls_response'
        managed = False

    def __str__(self):
        return f"{self.client_name} - {self.project_name}"
