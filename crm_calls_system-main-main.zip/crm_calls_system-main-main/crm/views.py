from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Q, Count
from django.db import connection
from .models import CallsResponse, UserProfile


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def get_user_profile(user):
    """Return profile, creating a 'sales' one if it doesn't exist yet."""
    profile = UserProfile.objects.get_or_create(user=user, defaults={'role': 'sales'})[0]
    return profile


def db_name(user):
    """Convert username / full-name dot-notation to DB space-notation."""
    name = user.get_full_name() or user.username
    return str(name).replace('.', ' ').strip()


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        user = authenticate(
            request,
            username=request.POST['username'],
            password=request.POST['password']
        )
        if user:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, 'Invalid username or password.')
    return render(request, 'crm/login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


# ---------------------------------------------------------------------------
# Dashboard — redirects to role-specific view
# ---------------------------------------------------------------------------

@login_required
def dashboard(request):
    profile = get_user_profile(request.user)
    if profile.is_sales_leader:
        return redirect('leader_dashboard')
    return sales_dashboard(request)


# ---------------------------------------------------------------------------
# Sales dashboard (personal stats)
# ---------------------------------------------------------------------------

def sales_dashboard(request):
    profile = get_user_profile(request.user)
    user_db_name = db_name(request.user)
    clients = CallsResponse.objects.filter(
        standard_lead_owner__iexact=user_db_name
    )

    total        = clients.count()
    interested   = clients.filter(status='Interested').count()
    not_interested = clients.filter(status='Not interested').count()
    scheduled    = clients.filter(status='Scheduled a meeting').count()
    recent       = clients.order_by('-id')[:5]

    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT project_name, COUNT(*) as cnt
            FROM calls_response
            WHERE LOWER(TRIM(standard_lead_owner)) = LOWER(%s)
              AND project_name IS NOT NULL
              AND project_name != ''
            GROUP BY project_name
            ORDER BY cnt DESC
            LIMIT 5
        """, [user_db_name])
        project_stats = cursor.fetchall()

    context = {
        'total': total,
        'interested': interested,
        'not_interested': not_interested,
        'scheduled': scheduled,
        'recent_clients': recent,
        'project_stats': project_stats,
        'profile': profile,
    }
    return render(request, 'crm/dashboard.html', context)


# ---------------------------------------------------------------------------
# Clients list — Sales sees own, Leader sees all (optionally filtered)
# ---------------------------------------------------------------------------

@login_required
def clients_list(request):
    profile = get_user_profile(request.user)
    query         = request.GET.get('q', '')
    status_filter = request.GET.get('status', '')
    owner_filter  = request.GET.get('owner', '')

    if profile.is_sales_leader:
        clients = CallsResponse.objects.all().order_by('-id')
        if owner_filter:
            clients = clients.filter(standard_lead_owner__iexact=owner_filter)
        # Build list of distinct owners for filter dropdown
        owners = (
            CallsResponse.objects
            .exclude(standard_lead_owner__isnull=True)
            .exclude(standard_lead_owner='')
            .values_list('standard_lead_owner', flat=True)
            .distinct()
            .order_by('standard_lead_owner')
        )
    else:
        user_db_name = db_name(request.user)
        clients = CallsResponse.objects.filter(
            standard_lead_owner__iexact=user_db_name
        ).order_by('-id')
        owners = None

    if query:
        clients = clients.filter(
            Q(client_name__icontains=query) |
            Q(project_name__icontains=query) |
            Q(phone_number__icontains=query) |
            Q(email_address__icontains=query)
        )
    if status_filter:
        clients = clients.filter(status=status_filter)

    context = {
        'clients': clients,
        'query': query,
        'status_filter': status_filter,
        'owner_filter': owner_filter,
        'owners': owners,
        'profile': profile,
    }
    return render(request, 'crm/clients.html', context)


# ---------------------------------------------------------------------------
# New client — both roles can add
# ---------------------------------------------------------------------------

@login_required
def new_client(request):
    from .forms import ClientForm
    profile = get_user_profile(request.user)
    user_db_name = db_name(request.user)

    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            with connection.cursor() as cursor:
                cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM calls_response")
                next_id = cursor.fetchone()[0]

            client = CallsResponse(
                id=next_id,
                lead_owner=form.cleaned_data['lead_owner'],
                phone_number=form.cleaned_data['phone_number'],
                client_code=form.cleaned_data['client_code'],
                client_name=form.cleaned_data['client_name'],
                project_name=form.cleaned_data['project_name'],
                date=form.cleaned_data['date'],
                notes=form.cleaned_data.get('notes', ''),
                status=form.cleaned_data['status'],
                type=form.cleaned_data.get('type', ''),
                email_address=form.cleaned_data['email_address'],
                location=form.cleaned_data['location'],
                manager_comments=form.cleaned_data.get('manager_comments', ''),
                standard_lead_owner=user_db_name,
                broker_name=form.cleaned_data.get('broker_name', ''),
            )
            client.save()
            messages.success(request, f'Client "{client.client_name}" added successfully!')
            return redirect('clients')
    else:
        form = ClientForm(initial={'lead_owner': user_db_name})

    return render(request, 'crm/new_client.html', {
        'form': form,
        'user_name': user_db_name,
        'profile': profile,
    })


# ---------------------------------------------------------------------------
# Edit client — ONLY Sales Leader
# ---------------------------------------------------------------------------

@login_required
def edit_client(request, pk):
    from .forms import ClientForm
    profile = get_user_profile(request.user)

    if not profile.is_sales_leader:
        messages.error(request, 'ليس لديك صلاحية تعديل بيانات العملاء.')
        return redirect('clients')

    client = get_object_or_404(CallsResponse, pk=pk)

    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            client.lead_owner        = form.cleaned_data['lead_owner']
            client.phone_number      = form.cleaned_data['phone_number']
            client.client_code       = form.cleaned_data['client_code']
            client.client_name       = form.cleaned_data['client_name']
            client.project_name      = form.cleaned_data['project_name']
            client.date              = form.cleaned_data['date']
            client.notes             = form.cleaned_data.get('notes', '')
            client.status            = form.cleaned_data['status']
            client.type              = form.cleaned_data.get('type', '')
            client.email_address     = form.cleaned_data['email_address']
            client.location          = form.cleaned_data['location']
            client.manager_comments  = form.cleaned_data.get('manager_comments', '')
            client.broker_name       = form.cleaned_data.get('broker_name', '')
            client.save()
            messages.success(request, f'Client "{client.client_name}" updated!')
            return redirect('clients')
    else:
        form = ClientForm(initial={
            'lead_owner':       client.lead_owner,
            'phone_number':     client.phone_number,
            'client_code':      client.client_code,
            'client_name':      client.client_name,
            'project_name':     client.project_name,
            'date':             client.date,
            'notes':            client.notes,
            'status':           client.status,
            'type':             client.type,
            'email_address':    client.email_address,
            'location':         client.location,
            'manager_comments': client.manager_comments,
            'broker_name':      client.broker_name,
        })

    return render(request, 'crm/new_client.html', {
        'form': form,
        'edit': True,
        'client': client,
        'user_name': db_name(request.user),
        'profile': profile,
    })


# ---------------------------------------------------------------------------
# Delete client — ONLY Sales Leader
# ---------------------------------------------------------------------------

@login_required
def delete_client(request, pk):
    profile = get_user_profile(request.user)

    if not profile.is_sales_leader:
        messages.error(request, 'ليس لديك صلاحية حذف العملاء.')
        return redirect('clients')

    client = get_object_or_404(CallsResponse, pk=pk)
    if request.method == 'POST':
        name = client.client_name
        client.delete()
        messages.success(request, f'Client "{name}" deleted.')
    return redirect('clients')


# ---------------------------------------------------------------------------
# Leader dashboard — shows all salespeople + per-person stats
# ---------------------------------------------------------------------------

@login_required
def leader_dashboard(request):
    profile = get_user_profile(request.user)
    if not profile.is_sales_leader:
        return redirect('dashboard')

    # Per-salesperson stats
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT
                standard_lead_owner,
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'Interested' THEN 1 ELSE 0 END)          AS interested,
                SUM(CASE WHEN status = 'Not interested' THEN 1 ELSE 0 END)      AS not_interested,
                SUM(CASE WHEN status = 'Scheduled a meeting' THEN 1 ELSE 0 END) AS scheduled
            FROM calls_response
            WHERE standard_lead_owner IS NOT NULL AND standard_lead_owner != ''
            GROUP BY standard_lead_owner
            ORDER BY total DESC
        """)
        rows = cursor.fetchall()

    sales_stats = []
    for row in rows:
        owner, total, interested, not_interested, scheduled = row
        sales_stats.append({
            'owner': owner,
            'total': total or 0,
            'interested': interested or 0,
            'not_interested': not_interested or 0,
            'scheduled': scheduled or 0,
        })

    # Team totals
    team_total          = sum(s['total'] for s in sales_stats)
    team_interested     = sum(s['interested'] for s in sales_stats)
    team_not_interested = sum(s['not_interested'] for s in sales_stats)
    team_scheduled      = sum(s['scheduled'] for s in sales_stats)

    context = {
        'sales_stats': sales_stats,
        'team_total': team_total,
        'team_interested': team_interested,
        'team_not_interested': team_not_interested,
        'team_scheduled': team_scheduled,
        'profile': profile,
    }
    return render(request, 'crm/leader_dashboard.html', context)


# ---------------------------------------------------------------------------
# Leader: view one salesperson's clients
# ---------------------------------------------------------------------------

@login_required
def leader_salesperson(request, owner_name):
    profile = get_user_profile(request.user)
    if not profile.is_sales_leader:
        return redirect('dashboard')

    query         = request.GET.get('q', '')
    status_filter = request.GET.get('status', '')

    clients = CallsResponse.objects.filter(
        standard_lead_owner__iexact=owner_name
    ).order_by('-id')

    if query:
        clients = clients.filter(
            Q(client_name__icontains=query) |
            Q(project_name__icontains=query) |
            Q(phone_number__icontains=query)
        )
    if status_filter:
        clients = clients.filter(status=status_filter)

    total          = clients.count()
    interested     = clients.filter(status='Interested').count()
    not_interested = clients.filter(status='Not interested').count()
    scheduled      = clients.filter(status='Scheduled a meeting').count()

    context = {
        'owner_name': owner_name,
        'clients': clients,
        'query': query,
        'status_filter': status_filter,
        'total': total,
        'interested': interested,
        'not_interested': not_interested,
        'scheduled': scheduled,
        'profile': profile,
    }
    return render(request, 'crm/leader_salesperson.html', context)
