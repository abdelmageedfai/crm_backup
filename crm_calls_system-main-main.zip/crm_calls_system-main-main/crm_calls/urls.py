from django.contrib import admin
from django.urls import path
from crm import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.login_view, name='login_root'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Dashboard — auto-redirects based on role
    path('dashboard/', views.dashboard, name='dashboard'),

    # Sales Leader dashboard
    path('leader/', views.leader_dashboard, name='leader_dashboard'),
    path('leader/salesperson/<str:owner_name>/', views.leader_salesperson, name='leader_salesperson'),

    # Clients
    path('clients/', views.clients_list, name='clients'),
    path('clients/new/', views.new_client, name='new_client'),
    path('clients/<int:pk>/edit/', views.edit_client, name='edit_client'),
    path('clients/<int:pk>/delete/', views.delete_client, name='delete_client'),
]
